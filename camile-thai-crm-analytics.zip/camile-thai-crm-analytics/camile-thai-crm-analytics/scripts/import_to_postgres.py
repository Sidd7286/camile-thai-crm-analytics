"""
Loads the six raw CSV datasets into PostgreSQL, then exports three of them
back out in a HubSpot-import-ready format (Contacts, Companies, Deals).

Setup:
    1. Copy .env.example to .env and fill in your local PostgreSQL credentials.
    2. pip install -r requirements.txt
    3. python scripts/import_to_postgres.py

Run from the repo root so the relative data paths resolve correctly.
"""

import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import create_engine

load_dotenv()

DB_USER = os.environ["DB_USER"]
DB_PASSWORD = os.environ["DB_PASSWORD"]
DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ.get("DB_NAME", "camile_crm_project")

engine = create_engine(
    f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

repo_root = Path(__file__).resolve().parent.parent
raw_data_folder = repo_root / "data" / "raw"
hubspot_export_folder = repo_root / "data" / "hubspot_exports"
hubspot_export_folder.mkdir(parents=True, exist_ok=True)

csv_files = {
    "branches": "IMPORT_1_companies_branches.csv",
    "customers": "IMPORT_2_contacts_customers.csv",
    "complaints": "IMPORT_3_deals_complaints.csv",
    "gdpr_blocked_contacts": "IMPORT_4_gdpr_blocked_contacts.csv",
    "orders": "orders.csv",
    "staff": "staff.csv",
}

for table_name, file_name in csv_files.items():
    file_path = raw_data_folder / file_name

    print(f"Reading: {file_name}")

    df = pd.read_csv(file_path)

    df.to_sql(
        table_name,
        engine,
        if_exists="replace",
        index=False,
    )

    print(f"Uploaded {table_name}: {len(df)} rows")

print("All files uploaded to PostgreSQL successfully.")

# -----------------------------
# EXPORT DATA FOR HUBSPOT
# -----------------------------

# Export Contacts (customers)
customers_df = pd.read_sql("SELECT * FROM customers", engine)
customers_df.to_csv(hubspot_export_folder / "hubspot_contacts.csv", index=False)

# Export Companies (branches)
branches_df = pd.read_sql("SELECT * FROM branches", engine)
branches_df.to_csv(hubspot_export_folder / "hubspot_companies.csv", index=False)

# Export Deals (complaints)
complaints_df = pd.read_sql("SELECT * FROM complaints", engine)
complaints_df.to_csv(hubspot_export_folder / "hubspot_deals.csv", index=False)

print("HubSpot CSV files created.")
